# NoteBoard — papan sticky note + widget Android

Aplikasi catatan dengan **widget beranda yang bisa diubah ukurannya**.
Isi: catatan, checklist, daftar kegiatan (dengan jam), pengingat, dan alarm.
Ada 9 tema: Sticky Kantor, Minimalis Putih, Mode Gelap, Papan Kayu, Buku Tulis,
Pastel Lucu, Neon Cyberpunk, Kaca, Alam.

## Membangun APK lewat GitHub (cukup dari HP)

1. Buka github.com di browser HP, login, ketuk **+ → New repository**.
   Beri nama `NoteBoard`, centang **Add a README file**, lalu **Create repository**.
2. Di repo itu ketuk **Add file → Upload files**, pilih **NoteBoard.zip**
   (jangan diekstrak), lalu **Commit changes**.
3. Ketuk **Add file → Create new file**. Di kolom nama ketik persis:
   `.github/workflows/build.yml`
   Tempelkan isi file `build.yml`, lalu **Commit changes**.
4. Buka tab **Actions**: tunggu sekitar 5–8 menit sampai tanda ✅ hijau.
5. Buka halaman utama repo → **Releases → NoteBoard** → unduh **NoteBoard.apk**.
6. Buka file APK di HP → izinkan "Instal dari sumber ini" → **Instal**.

Jika build gagal (❌), buka Actions → klik build yang gagal → salin pesan error-nya
dan kirim ke Claude untuk diperbaiki.

## Pasang widget
Tahan layar beranda → **Widget** → **NoteBoard** → seret ke beranda → pilih isinya.
Ubah ukuran: tahan widget lalu tarik tepinya. Checklist bisa dicentang langsung dari widget.

## Agar alarm andal
- Izinkan notifikasi saat diminta.
- Pengaturan aplikasi (⚙️) → **Izinkan alarm layar penuh** (Android 14+).
- Di beberapa HP (Xiaomi, Oppo, Vivo, Samsung): Pengaturan → Baterai →
  NoteBoard → **Tanpa batasan**, supaya alarm tidak dimatikan sistem.
