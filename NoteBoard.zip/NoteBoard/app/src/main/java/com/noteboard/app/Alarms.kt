package com.noteboard.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import java.util.Calendar

object AlarmScheduler {
    const val ACTION_FIRE = "com.noteboard.app.FIRE"
    const val ACTION_SNOOZE = "com.noteboard.app.SNOOZE"
    const val ACTION_DISMISS = "com.noteboard.app.DISMISS"
    const val EXTRA_ID = "noteId"
    const val EXTRA_SNOOZE = "snooze"
    const val SNOOZE_MIN = 5

    fun req(id: Long, offset: Int = 0): Int = ((id xor (id ushr 32)).toInt() and 0x0FFFFFFF) * 2 + offset

    private fun firePi(ctx: Context, id: Long, snooze: Boolean, flags: Int): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java)
            .setAction(ACTION_FIRE)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        return PendingIntent.getBroadcast(
            ctx, req(id, if (snooze) 1 else 0), i, flags or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun nextTrigger(n: Note, now: Long = System.currentTimeMillis()): Long {
        if (n.timeMillis <= 0) return -1
        if (n.repeat == Repeat.NONE) return n.timeMillis
        val c = Calendar.getInstance().apply { timeInMillis = n.timeMillis }
        val step = if (n.repeat == Repeat.DAILY) 1 else 7
        var guard = 0
        while (c.timeInMillis <= now && guard < 5000) {
            c.add(Calendar.DAY_OF_YEAR, step)
            guard++
        }
        return c.timeInMillis
    }

    fun schedule(ctx: Context, n: Note) {
        cancel(ctx, n.id)
        if (n.type != NoteType.REMINDER && n.type != NoteType.ALARM) return
        if (!n.enabled || n.archived) return
        val t = nextTrigger(n, System.currentTimeMillis() + 1000)
        if (t <= System.currentTimeMillis()) return
        val pi = firePi(ctx, n.id, false, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        setAt(ctx, t, pi, n.type == NoteType.ALARM)
    }

    private fun setAt(ctx: Context, t: Long, pi: PendingIntent, alarmClock: Boolean) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val exact = Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        try {
            if (exact) {
                if (alarmClock) {
                    val show = PendingIntent.getActivity(
                        ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
                    )
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                }
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        firePi(ctx, id, false, PendingIntent.FLAG_NO_CREATE)?.let { am.cancel(it); it.cancel() }
    }

    fun snooze(ctx: Context, id: Long) {
        dismiss(ctx, id)
        val pi = firePi(ctx, id, true, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        setAt(ctx, System.currentTimeMillis() + SNOOZE_MIN * 60_000L, pi, true)
    }

    fun dismiss(ctx: Context, id: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(req(id))
    }

    fun rescheduleAll(ctx: Context) {
        NoteRepo.all(ctx).forEach { schedule(ctx, it) }
    }
}

object Notifs {
    const val CH_ALARM = "alarm_v1"
    const val CH_REMINDER = "reminder_v1"

    fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: Settings.System.DEFAULT_ALARM_ALERT_URI
        val alarm = NotificationChannel(CH_ALARM, "Alarm", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Alarm berbunyi"
            setSound(
                sound,
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 800, 600, 800)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        val rem = NotificationChannel(CH_REMINDER, "Pengingat", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Pengingat catatan"
        }
        nm.createNotificationChannels(listOf(alarm, rem))
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        if (id == -1L) return
        when (intent.action) {
            AlarmScheduler.ACTION_SNOOZE -> AlarmScheduler.snooze(ctx, id)
            AlarmScheduler.ACTION_DISMISS -> AlarmScheduler.dismiss(ctx, id)
            AlarmScheduler.ACTION_FIRE -> fire(ctx, id, intent.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false))
        }
    }

    private fun fire(ctx: Context, id: Long, snooze: Boolean) {
        val n = NoteRepo.get(ctx, id) ?: return
        Notifs.ensure(ctx)
        if (n.type == NoteType.ALARM) showAlarm(ctx, n) else showReminder(ctx, n)
        if (!snooze) {
            if (n.repeat != Repeat.NONE) {
                AlarmScheduler.schedule(ctx, n)
            } else if (n.type == NoteType.ALARM) {
                n.enabled = false
                NoteRepo.upsert(ctx, n)
            }
        }
    }

    private fun showAlarm(ctx: Context, n: Note) {
        val req = AlarmScheduler.req(n.id)
        val full = Intent(ctx, AlarmActivity::class.java)
            .putExtra(AlarmScheduler.EXTRA_ID, n.id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        val fullPi = PendingIntent.getActivity(
            ctx, req, full, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        fun action(a: String) = PendingIntent.getBroadcast(
            ctx, req,
            Intent(ctx, AlarmReceiver::class.java).setAction(a).putExtra(AlarmScheduler.EXTRA_ID, n.id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notif = NotificationCompat.Builder(ctx, Notifs.CH_ALARM)
            .setSmallIcon(R.drawable.ic_stat_note)
            .setContentTitle("⏰ " + n.displayTitle())
            .setContentText("Sekarang " + Fmt.time(System.currentTimeMillis()))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setFullScreenIntent(fullPi, true)
            .setContentIntent(fullPi)
            .setOngoing(true)
            .setAutoCancel(false)
            .addAction(0, "Tunda ${AlarmScheduler.SNOOZE_MIN} mnt", action(AlarmScheduler.ACTION_SNOOZE))
            .addAction(0, "Matikan", action(AlarmScheduler.ACTION_DISMISS))
            .build()
        notif.flags = notif.flags or Notification.FLAG_INSISTENT
        ctx.getSystemService(NotificationManager::class.java).notify(req, notif)
    }

    private fun showReminder(ctx: Context, n: Note) {
        val req = AlarmScheduler.req(n.id)
        val open = Intent(ctx, EditorActivity::class.java)
            .putExtra("id", n.id)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            ctx, req, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notif = NotificationCompat.Builder(ctx, Notifs.CH_REMINDER)
            .setSmallIcon(R.drawable.ic_stat_note)
            .setContentTitle("🔔 " + n.displayTitle())
            .setContentText(n.body.ifBlank { "Waktunya: " + Fmt.time(System.currentTimeMillis()) })
            .setStyle(NotificationCompat.BigTextStyle().bigText(n.body.ifBlank { n.displayTitle() }))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        ctx.getSystemService(NotificationManager::class.java).notify(req, notif)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(ctx)
        NoteWidgetProvider.updateAll(ctx)
    }
}
