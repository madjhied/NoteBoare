package com.noteboard.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import java.util.Calendar
import java.util.Locale

class EditorActivity : AppCompatActivity() {

    private lateinit var note: Note
    private var isNew = false
    private val cal: Calendar = Calendar.getInstance()
    private lateinit var theme: BoardTheme

    private class RowViews(val root: View, val check: CheckBox, val time: TextView, val text: EditText)
    private val rows = mutableListOf<RowViews>()

    private lateinit var editTitle: EditText
    private lateinit var editBody: EditText
    private lateinit var itemsContainer: LinearLayout
    private lateinit var btnAddItem: TextView
    private lateinit var timeSection: LinearLayout
    private lateinit var btnDate: Button
    private lateinit var btnTime: Button
    private lateinit var repeatGroup: RadioGroup
    private lateinit var switchEnabled: SwitchCompat
    private lateinit var card: LinearLayout
    private lateinit var colorRow: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_editor)
        theme = Themes.current(this)

        val id = intent.getLongExtra("id", -1L)
        val existing = if (id != -1L) NoteRepo.get(this, id) else null
        if (existing != null) {
            note = existing
        } else {
            isNew = true
            val type = runCatching { NoteType.valueOf(intent.getStringExtra("type") ?: "") }
                .getOrDefault(NoteType.NOTE)
            note = Note(NoteRepo.newId(), type, color = (0..4).random())
        }

        if (note.timeMillis > 0) {
            cal.timeInMillis = note.timeMillis
        } else {
            cal.add(Calendar.HOUR_OF_DAY, 1)
            cal.set(Calendar.MINUTE, 0)
        }
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        editTitle = findViewById(R.id.edit_title)
        editBody = findViewById(R.id.edit_body)
        itemsContainer = findViewById(R.id.items_container)
        btnAddItem = findViewById(R.id.btn_add_item)
        timeSection = findViewById(R.id.time_section)
        btnDate = findViewById(R.id.btn_date)
        btnTime = findViewById(R.id.btn_time)
        repeatGroup = findViewById(R.id.repeat_group)
        switchEnabled = findViewById(R.id.switch_enabled)
        card = findViewById(R.id.editor_card)
        colorRow = findViewById(R.id.color_row)

        findViewById<TextView>(R.id.type_label).text = "${note.type.icon}  ${note.type.label}"
        findViewById<View>(R.id.btn_back).setOnClickListener { save() }
        findViewById<View>(R.id.btn_save).setOnClickListener { save() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = save()
        })

        editTitle.setText(note.title)
        editBody.setText(note.body)
        setupByType()
        applyTheme()
    }

    private fun setupByType() {
        val type = note.type
        val hasItems = type == NoteType.CHECKLIST || type == NoteType.ACTIVITY
        val hasTime = type == NoteType.REMINDER || type == NoteType.ALARM

        editBody.visibility = if (type == NoteType.NOTE || type == NoteType.REMINDER) View.VISIBLE else View.GONE
        if (type == NoteType.REMINDER) {
            editBody.hint = "Keterangan (opsional)"
            editBody.minLines = 2
        }
        itemsContainer.visibility = if (hasItems) View.VISIBLE else View.GONE
        btnAddItem.visibility = if (hasItems) View.VISIBLE else View.GONE
        timeSection.visibility = if (hasTime) View.VISIBLE else View.GONE
        editTitle.hint = when (type) {
            NoteType.ALARM -> "Label alarm (mis. Bangun pagi)"
            NoteType.REMINDER -> "Ingatkan saya untuk…"
            NoteType.ACTIVITY -> "Judul (mis. Kegiatan Senin)"
            else -> "Judul"
        }

        if (hasItems) {
            note.items.forEach { addRow(it, false) }
            if (note.items.isEmpty()) addRow(Item(""), true)
            btnAddItem.setOnClickListener { addRow(Item(""), true) }
        }

        if (hasTime) {
            btnDate.visibility = if (type == NoteType.REMINDER) View.VISIBLE else View.GONE
            btnDate.setOnClickListener {
                DatePickerDialog(this, { _, y, m, d ->
                    cal.set(y, m, d)
                    updateTimeButtons()
                }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
            }
            btnTime.setOnClickListener {
                TimePickerDialog(this, { _, h, mi ->
                    cal.set(Calendar.HOUR_OF_DAY, h)
                    cal.set(Calendar.MINUTE, mi)
                    updateTimeButtons()
                }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
            }
            repeatGroup.check(
                when (note.repeat) {
                    Repeat.NONE -> R.id.r_none
                    Repeat.DAILY -> R.id.r_daily
                    Repeat.WEEKLY -> R.id.r_weekly
                }
            )
            switchEnabled.isChecked = note.enabled
            updateTimeButtons()
        }
    }

    private fun updateTimeButtons() {
        btnDate.text = "📆  " + Fmt.date(cal.timeInMillis)
        btnTime.text = "🕒  " + Fmt.time(cal.timeInMillis)
    }

    private fun addRow(item: Item, focus: Boolean) {
        val v = LayoutInflater.from(this).inflate(R.layout.item_edit_row, itemsContainer, false)
        val row = RowViews(v, v.findViewById(R.id.row_check), v.findViewById(R.id.row_time), v.findViewById(R.id.row_text))
        row.check.isChecked = item.done
        row.text.setText(item.text)
        row.time.tag = item.time
        row.time.text = item.time.ifBlank { "--:--" }
        row.time.visibility = if (note.type == NoteType.ACTIVITY) View.VISIBLE else View.GONE
        row.time.setOnClickListener {
            val parts = (row.time.tag as? String).orEmpty().split(":")
            val h = parts.getOrNull(0)?.toIntOrNull() ?: 8
            val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
            TimePickerDialog(this, { _, hh, mm ->
                val s = String.format(Locale.US, "%02d:%02d", hh, mm)
                row.time.tag = s
                row.time.text = s
            }, h, m, true).show()
        }
        row.text.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_NEXT || actionId == EditorInfo.IME_ACTION_DONE) {
                if (rows.lastOrNull() === row) addRow(Item(""), true) else {
                    rows.getOrNull(rows.indexOf(row) + 1)?.text?.requestFocus()
                }
                true
            } else false
        }
        v.findViewById<View>(R.id.row_delete).setOnClickListener {
            itemsContainer.removeView(v)
            rows.remove(row)
        }
        styleRow(row)
        rows.add(row)
        itemsContainer.addView(v)
        if (focus) row.text.requestFocus()
    }

    private fun styleRow(r: RowViews) {
        val tf = theme.typeface()
        r.text.typeface = tf
        r.text.setTextColor(theme.text)
        r.text.setHintTextColor(theme.subText)
        r.time.setTextColor(theme.accent)
        r.time.typeface = theme.typefaceBold()
        r.check.buttonTintList = ColorStateList.valueOf(theme.accent)
        (r.root.findViewById<TextView>(R.id.row_delete)).setTextColor(theme.subText)
    }

    private fun applyTheme() {
        val t = theme
        findViewById<View>(R.id.editor_root).background = t.background()
        window.statusBarColor = t.bgTop
        window.navigationBarColor = t.bgBottom
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !t.dark
            isAppearanceLightNavigationBars = !t.dark
        }
        val headerColor = if (t.dark) 0xFFFFFFFF.toInt() else t.text
        findViewById<TextView>(R.id.btn_back).setTextColor(headerColor)
        findViewById<TextView>(R.id.type_label).apply { setTextColor(headerColor); typeface = t.typefaceBold() }
        findViewById<Button>(R.id.btn_save).apply {
            backgroundTintList = ColorStateList.valueOf(t.accent)
            setTextColor(if (ColorUtils.calculateLuminance(t.accent) > 0.5) 0xFF222222.toInt() else 0xFFFFFFFF.toInt())
        }

        editTitle.typeface = t.typefaceBold()
        editTitle.setTextColor(t.text)
        editTitle.setHintTextColor(t.subText)
        editBody.typeface = t.typeface()
        editBody.setTextColor(t.text)
        editBody.setHintTextColor(t.subText)
        btnAddItem.setTextColor(t.accent)
        btnAddItem.typeface = t.typefaceBold()
        btnDate.setTextColor(t.text)
        btnTime.setTextColor(t.text)
        switchEnabled.setTextColor(t.text)
        for (i in 0 until repeatGroup.childCount) {
            (repeatGroup.getChildAt(i) as? RadioButton)?.apply {
                setTextColor(t.text)
                buttonTintList = ColorStateList.valueOf(t.accent)
            }
        }
        paintCard()
        buildColors()
    }

    private fun paintCard() {
        card.background = Themes.card(this, theme, theme.cardColor(note.color))
        card.elevation = dp(theme.elevationDp)
        card.outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        val left = if (theme.lined) dpi(34f) else dpi(18f)
        card.setPadding(left, dpi(16f), dpi(18f), dpi(20f))
    }

    private fun buildColors() {
        colorRow.removeAllViews()
        theme.cards.forEachIndexed { i, col ->
            val v = View(this)
            val size = dpi(30f)
            val lp = LinearLayout.LayoutParams(size, size)
            lp.marginEnd = dpi(10f)
            v.layoutParams = lp
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(col)
                val selected = note.color.mod(theme.cards.size) == i
                setStroke(dpi(if (selected) 3f else 1f), if (selected) theme.accent else 0x55000000)
            }
            v.setOnClickListener {
                note.color = i
                paintCard()
                buildColors()
            }
            colorRow.addView(v)
        }
    }

    private fun save() {
        note.title = editTitle.text.toString().trim()
        note.body = editBody.text.toString().trimEnd()

        if (note.type == NoteType.CHECKLIST || note.type == NoteType.ACTIVITY) {
            note.items.clear()
            rows.forEach { r ->
                val txt = r.text.text.toString().trim()
                if (txt.isNotEmpty()) note.items.add(Item(txt, r.check.isChecked, (r.time.tag as? String).orEmpty()))
            }
            if (note.type == NoteType.ACTIVITY) note.items.sortBy { it.time.ifBlank { "99:99" } }
        }

        if (note.type == NoteType.REMINDER || note.type == NoteType.ALARM) {
            note.repeat = when (repeatGroup.checkedRadioButtonId) {
                R.id.r_daily -> Repeat.DAILY
                R.id.r_weekly -> Repeat.WEEKLY
                else -> Repeat.NONE
            }
            note.enabled = switchEnabled.isChecked
            if (note.type == NoteType.ALARM) {
                val c = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, cal.get(Calendar.HOUR_OF_DAY))
                    set(Calendar.MINUTE, cal.get(Calendar.MINUTE))
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                note.timeMillis = c.timeInMillis
            } else {
                note.timeMillis = cal.timeInMillis
            }
        }

        val empty = note.title.isBlank() && note.body.isBlank() && note.items.isEmpty() &&
            note.type != NoteType.ALARM && note.type != NoteType.REMINDER
        if (isNew && empty) {
            finish(); return
        }

        NoteRepo.upsert(this, note)
        AlarmScheduler.schedule(this, note)

        if ((note.type == NoteType.ALARM || note.type == NoteType.REMINDER) && note.enabled) {
            val next = AlarmScheduler.nextTrigger(note)
            val msg = if (next > System.currentTimeMillis()) "Berbunyi dalam ${Fmt.until(next)}"
            else "Waktu sudah lewat — pengingat tidak dijadwalkan"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
        finish()
    }
}
