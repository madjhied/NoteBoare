package com.noteboard.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils

class NoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(ctx, mgr, it) }
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        ids.forEach { Prefs.removeWidget(ctx, it) }
    }

    override fun onAppWidgetOptionsChanged(ctx: Context, mgr: AppWidgetManager, id: Int, newOptions: Bundle?) {
        update(ctx, mgr, id)
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        super.onReceive(ctx, intent)
        if (intent.action == ACTION_TOGGLE) {
            val noteId = intent.getLongExtra(EXTRA_NOTE, -1L)
            val idx = intent.getIntExtra(EXTRA_ITEM, -1)
            val list = NoteRepo.all(ctx)
            val n = list.find { it.id == noteId } ?: return
            if (idx in n.items.indices) {
                n.items[idx].done = !n.items[idx].done
                NoteRepo.saveAll(ctx, list)
            }
        }
    }

    companion object {
        const val ACTION_TOGGLE = "com.noteboard.app.WIDGET_TOGGLE"
        const val EXTRA_NOTE = "noteId"
        const val EXTRA_ITEM = "item"

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, widgetId: Int) {
            val t = Themes.current(ctx)
            val noteId = Prefs.widgetNote(ctx, widgetId)
            val note = if (noteId != -1L) NoteRepo.get(ctx, noteId) else null
            val rv = RemoteViews(ctx.packageName, R.layout.widget_note)

            rv.setInt(R.id.widget_root, "setBackgroundResource", t.widgetBg)
            val title = note?.let { "${it.type.icon} ${it.displayTitle()}" } ?: "📋 NoteBoard"
            rv.setTextViewText(R.id.widget_title, title)
            rv.setTextColor(R.id.widget_title, t.widgetText)
            rv.setTextColor(R.id.widget_edit, t.widgetText)
            rv.setTextColor(R.id.widget_empty, ColorUtils.setAlphaComponent(t.widgetText, 170))
            rv.setTextViewText(
                R.id.widget_empty,
                if (note == null && noteId != -1L) "Catatan sudah dihapus.\nTahan widget → atur ulang."
                else "Belum ada isi. Ketuk ✎"
            )

            // Daftar isi widget
            val svc = Intent(ctx, WidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            @Suppress("DEPRECATION")
            rv.setRemoteAdapter(R.id.widget_list, svc)
            rv.setEmptyView(R.id.widget_list, R.id.widget_empty)

            // Ketuk baris: centang (checklist) atau buka catatan
            val toggleable = note != null && (note.type == NoteType.CHECKLIST || note.type == NoteType.ACTIVITY)
            val template = if (toggleable) {
                PendingIntent.getBroadcast(
                    ctx, widgetId,
                    Intent(ctx, NoteWidgetProvider::class.java).setAction(ACTION_TOGGLE),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
            } else {
                PendingIntent.getActivity(
                    ctx, widgetId,
                    Intent(ctx, EditorActivity::class.java),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
                )
            }
            rv.setPendingIntentTemplate(R.id.widget_list, template)

            // Tombol ✎ dan judul
            val openIntent = if (note != null) {
                Intent(ctx, EditorActivity::class.java).putExtra("id", note.id)
            } else {
                Intent(ctx, MainActivity::class.java)
            }
            val openPi = PendingIntent.getActivity(
                ctx, widgetId + 100_000, openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.widget_edit, openPi)
            val appPi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            rv.setOnClickPendingIntent(R.id.widget_title, appPi)

            mgr.updateAppWidget(widgetId, rv)
            @Suppress("DEPRECATION")
            mgr.notifyAppWidgetViewDataChanged(widgetId, R.id.widget_list)
        }
    }
}

class WidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory =
        Factory(applicationContext, intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0))

    private data class Row(val text: CharSequence, val noteId: Long, val item: Int)

    private class Factory(val ctx: Context, val widgetId: Int) : RemoteViewsService.RemoteViewsFactory {
        private var rows: List<Row> = emptyList()
        private var color = 0

        override fun onCreate() {}
        override fun onDestroy() {}

        override fun onDataSetChanged() {
            val t = Themes.current(ctx)
            color = t.widgetText
            val noteId = Prefs.widgetNote(ctx, widgetId)
            rows = if (noteId == -1L) {
                NoteRepo.all(ctx).filter { !it.archived }
                    .sortedByDescending { it.pinned }
                    .map { Row("${it.type.icon} ${it.displayTitle()}  ·  ${it.summary()}", it.id, -1) }
            } else {
                val n = NoteRepo.get(ctx, noteId)
                if (n == null) emptyList() else when (n.type) {
                    NoteType.NOTE -> n.body.lines().filter { it.isNotBlank() }.map { Row(it, n.id, -1) }
                    NoteType.CHECKLIST, NoteType.ACTIVITY -> n.items.mapIndexed { i, item ->
                        val time = if (item.time.isNotBlank()) "${item.time}  " else ""
                        val label = (if (item.done) "☑  " else "☐  ") + time + item.text
                        val s = SpannableString(label)
                        if (item.done) s.setSpan(StrikethroughSpan(), 3, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        Row(s, n.id, i)
                    }
                    NoteType.REMINDER, NoteType.ALARM -> listOfNotNull(
                        Row("${n.type.icon} ${Fmt.schedule(n)}", n.id, -1),
                        n.body.takeIf { it.isNotBlank() }?.let { Row(it, n.id, -1) }
                    )
                }
            }
        }

        override fun getCount(): Int = rows.size

        override fun getViewAt(position: Int): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)
            val r = rows.getOrNull(position) ?: return rv
            rv.setTextViewText(R.id.widget_item_text, r.text)
            rv.setTextColor(R.id.widget_item_text, color)
            val fill = Intent()
                .putExtra(NoteWidgetProvider.EXTRA_NOTE, r.noteId)
                .putExtra(NoteWidgetProvider.EXTRA_ITEM, r.item)
                .putExtra("id", r.noteId)
            rv.setOnClickFillInIntent(R.id.widget_item_text, fill)
            return rv
        }

        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount(): Int = 1
        override fun getItemId(position: Int): Long = position.toLong()
        override fun hasStableIds(): Boolean = false
    }
}

class WidgetConfigActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        val widgetId = intent.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish(); return
        }

        val notes = NoteRepo.all(this).filter { !it.archived }
        val labels = mutableListOf("📋  Ringkasan semua catatan")
        notes.forEach { labels.add("${it.type.icon}  ${it.displayTitle()}") }
        labels.add("➕  Buat checklist baru")

        AlertDialog.Builder(this)
            .setTitle("Pilih isi widget")
            .setItems(labels.toTypedArray()) { _, which ->
                var openEditor = -1L
                val noteId = when {
                    which == 0 -> -1L
                    which <= notes.size -> notes[which - 1].id
                    else -> {
                        val n = Note(NoteRepo.newId(), NoteType.CHECKLIST, "Checklist baru")
                        NoteRepo.upsert(this, n)
                        openEditor = n.id
                        n.id
                    }
                }
                Prefs.setWidgetNote(this, widgetId, noteId)
                NoteWidgetProvider.update(this, AppWidgetManager.getInstance(this), widgetId)
                setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
                if (openEditor != -1L) {
                    startActivity(Intent(this, EditorActivity::class.java).putExtra("id", openEditor))
                }
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }
}
