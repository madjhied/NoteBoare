package com.noteboard.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import androidx.core.graphics.ColorUtils

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Float): Int = dp(v).toInt()

private fun c(hex: Long): Int = hex.toInt()

data class BoardTheme(
    val name: String,
    val bgTop: Int,
    val bgBottom: Int,
    val cards: List<Int>,
    val text: Int,
    val subText: Int,
    val accent: Int,
    val stroke: Int = Color.TRANSPARENT,
    val strokeDp: Float = 0f,
    val radiusDp: Float = 12f,
    val font: String = "sans-serif",
    val elevationDp: Float = 3f,
    val lined: Boolean = false,
    val fold: Boolean = false,
    val decor: String = "",
    val dark: Boolean = false,
    val widgetBg: Int,
    val widgetText: Int
) {
    fun cardColor(index: Int): Int = cards[index.mod(cards.size)]
    fun typeface(): Typeface = Typeface.create(font, Typeface.NORMAL)
    fun typefaceBold(): Typeface = Typeface.create(font, Typeface.BOLD)
    fun background(): Drawable =
        GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, bgBottom))
}

object Themes {
    val list: List<BoardTheme> = listOf(
        BoardTheme(
            "Sticky Kantor", c(0xFFE8E2D0), c(0xFFD9D0B8),
            listOf(c(0xFFFFF59D), c(0xFFF8BBD0), c(0xFFB3E5FC), c(0xFFC8E6C9), c(0xFFFFE0B2)),
            c(0xFF333333), c(0xFF6D6D6D), c(0xFFF9A825),
            radiusDp = 2f, font = "casual", elevationDp = 6f, fold = true,
            widgetBg = R.drawable.widget_bg_0, widgetText = c(0xFF333333)
        ),
        BoardTheme(
            "Minimalis Putih", c(0xFFFAFAFA), c(0xFFF2F2F2),
            listOf(c(0xFFFFFFFF), c(0xFFF7F7F7), c(0xFFFFFFFF), c(0xFFF1F4F8)),
            c(0xFF1F1F1F), c(0xFF8A8A8A), c(0xFF111111),
            stroke = c(0xFFE0E0E0), strokeDp = 1f, radiusDp = 14f, font = "sans-serif-light", elevationDp = 0f,
            widgetBg = R.drawable.widget_bg_1, widgetText = c(0xFF1F1F1F)
        ),
        BoardTheme(
            "Mode Gelap", c(0xFF121212), c(0xFF0A0A0A),
            listOf(c(0xFF1E1E1E), c(0xFF22303A), c(0xFF2A2238), c(0xFF1F3329), c(0xFF3A2A1E)),
            c(0xFFEDEDED), c(0xFF9E9E9E), c(0xFF80CBC4),
            radiusDp = 16f, elevationDp = 2f, dark = true,
            widgetBg = R.drawable.widget_bg_2, widgetText = c(0xFFEDEDED)
        ),
        BoardTheme(
            "Papan Kayu", c(0xFF8D6E63), c(0xFF5D4037),
            listOf(c(0xFFFFF8E1), c(0xFFFFECB3), c(0xFFF1F8E9), c(0xFFFCE4EC), c(0xFFE3F2FD)),
            c(0xFF3E2723), c(0xFF795548), c(0xFFD84315),
            radiusDp = 3f, font = "serif", elevationDp = 8f, decor = "📌", dark = true,
            widgetBg = R.drawable.widget_bg_3, widgetText = c(0xFF3E2723)
        ),
        BoardTheme(
            "Buku Tulis", c(0xFFECEFF1), c(0xFFCFD8DC),
            listOf(c(0xFFFFFFFF), c(0xFFFFFDE7), c(0xFFF3F8FF)),
            c(0xFF263238), c(0xFF607D8B), c(0xFFE53935),
            stroke = c(0xFFB0BEC5), strokeDp = 1f, radiusDp = 4f, font = "casual", elevationDp = 2f, lined = true,
            widgetBg = R.drawable.widget_bg_4, widgetText = c(0xFF263238)
        ),
        BoardTheme(
            "Pastel Lucu", c(0xFFFCE4EC), c(0xFFE1F5FE),
            listOf(c(0xFFF8BBD0), c(0xFFE1BEE7), c(0xFFB2EBF2), c(0xFFDCEDC8), c(0xFFFFF9C4)),
            c(0xFF4A3B4F), c(0xFF8E7A93), c(0xFFEC407A),
            radiusDp = 26f, font = "casual", elevationDp = 4f, decor = "🌸",
            widgetBg = R.drawable.widget_bg_5, widgetText = c(0xFF4A3B4F)
        ),
        BoardTheme(
            "Neon Cyberpunk", c(0xFF0D0221), c(0xFF1B0A3C),
            listOf(c(0xFF1A0B3B), c(0xFF0F1A3D), c(0xFF2A0A33)),
            c(0xFFE0E6FF), c(0xFF9FA8DA), c(0xFFFF2BD6),
            stroke = c(0xFF00F5FF), strokeDp = 1.5f, radiusDp = 8f, font = "monospace", elevationDp = 0f, dark = true,
            widgetBg = R.drawable.widget_bg_6, widgetText = c(0xFFE0E6FF)
        ),
        BoardTheme(
            "Kaca", c(0xFF667EEA), c(0xFF764BA2),
            listOf(c(0x40FFFFFF), c(0x33FFFFFF), c(0x4DFFFFFF)),
            c(0xFFFFFFFF), c(0xDDFFFFFF), c(0xFFFFFFFF),
            stroke = c(0x80FFFFFF), strokeDp = 1f, radiusDp = 20f, elevationDp = 0f, dark = true,
            widgetBg = R.drawable.widget_bg_7, widgetText = c(0xFFFFFFFF)
        ),
        BoardTheme(
            "Alam", c(0xFFE8F5E9), c(0xFFDCE8D2),
            listOf(c(0xFFF1F8E9), c(0xFFDCEDC8), c(0xFFFFF3E0), c(0xFFD7CCC8), c(0xFFE0F2F1)),
            c(0xFF1B3A1E), c(0xFF5D7A60), c(0xFF2E7D32),
            radiusDp = 18f, font = "serif", elevationDp = 3f, decor = "🍃",
            widgetBg = R.drawable.widget_bg_8, widgetText = c(0xFF1B3A1E)
        )
    )

    fun current(ctx: Context): BoardTheme = list[Prefs.theme(ctx).coerceIn(0, list.size - 1)]

    fun card(ctx: Context, t: BoardTheme, fill: Int): CardDrawable = CardDrawable(
        fill = fill,
        stroke = t.stroke,
        strokeW = ctx.dp(t.strokeDp),
        radius = ctx.dp(t.radiusDp),
        lined = t.lined,
        fold = t.fold,
        lineGap = ctx.dp(22f)
    )
}

class CardDrawable(
    private val fill: Int,
    private val stroke: Int,
    private val strokeW: Float,
    private val radius: Float,
    private val lined: Boolean,
    private val fold: Boolean,
    private val lineGap: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun draw(canvas: Canvas) {
        val r = RectF(bounds)
        paint.style = Paint.Style.FILL
        paint.color = fill
        canvas.drawRoundRect(r, radius, radius, paint)

        if (lined) {
            paint.strokeWidth = 1.5f
            paint.color = 0x5590CAF9
            var y = r.top + lineGap * 2
            while (y < r.bottom - 4) {
                canvas.drawLine(r.left + 6, y, r.right - 6, y, paint)
                y += lineGap
            }
            paint.color = 0x99E57373.toInt()
            val x = r.left + lineGap * 1.1f
            canvas.drawLine(x, r.top, x, r.bottom, paint)
        }

        if (fold) {
            val f = minOf(r.width(), r.height()) * 0.12f
            val p = Path().apply {
                moveTo(r.right - f, r.bottom)
                lineTo(r.right, r.bottom - f)
                lineTo(r.right - f, r.bottom - f)
                close()
            }
            paint.style = Paint.Style.FILL
            paint.color = ColorUtils.blendARGB(fill, Color.BLACK, 0.18f)
            canvas.drawPath(p, paint)
        }

        if (strokeW > 0f) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = strokeW
            paint.color = stroke
            r.inset(strokeW / 2, strokeW / 2)
            canvas.drawRoundRect(r, radius, radius, paint)
        }
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, radius)
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
