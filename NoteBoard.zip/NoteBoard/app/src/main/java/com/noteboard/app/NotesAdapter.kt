package com.noteboard.app

import android.content.Context
import android.graphics.Paint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NotesAdapter(
    private val ctx: Context,
    private val onOpen: (Note) -> Unit,
    private val onMore: (Note, View) -> Unit,
    private val onChanged: (Note) -> Unit
) : RecyclerView.Adapter<NotesAdapter.VH>() {

    val items = mutableListOf<Note>()
    var theme: BoardTheme = Themes.list[0]
    var scale = 1f

    fun submit(list: List<Note>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun move(from: Int, to: Int) {
        val n = items.removeAt(from)
        items.add(to, n)
        notifyItemMoved(from, to)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val decor: TextView = v.findViewById(R.id.card_decor)
        val title: TextView = v.findViewById(R.id.card_title)
        val pin: TextView = v.findViewById(R.id.card_pin)
        val more: TextView = v.findViewById(R.id.card_more)
        val meta: TextView = v.findViewById(R.id.card_meta)
        val content: LinearLayout = v.findViewById(R.id.card_content)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_note, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val n = items[position]
        val t = theme
        val v = h.itemView

        v.background = Themes.card(ctx, t, t.cardColor(n.color))
        v.outlineProvider = ViewOutlineProvider.BACKGROUND
        v.elevation = ctx.dp(t.elevationDp)
        val lineIndent = if (t.lined) ctx.dpi(30f) else ctx.dpi(14f)
        v.setPadding(lineIndent, ctx.dpi(12f), ctx.dpi(14f), ctx.dpi(16f))

        h.decor.text = t.decor
        h.decor.visibility = if (t.decor.isBlank()) View.GONE else View.VISIBLE

        h.title.text = "${n.type.icon} ${n.displayTitle()}"
        h.title.typeface = t.typefaceBold()
        h.title.textSize = 17f * scale
        h.title.setTextColor(t.text)
        h.pin.visibility = if (n.pinned) View.VISIBLE else View.GONE
        h.more.setTextColor(t.subText)

        h.meta.typeface = t.typeface()
        h.meta.textSize = 12f * scale
        h.meta.setTextColor(t.subText)
        h.meta.visibility = View.VISIBLE

        h.content.removeAllViews()
        when (n.type) {
            NoteType.NOTE -> {
                h.meta.visibility = View.GONE
                addText(h, n.body.ifBlank { "(kosong)" }, 15f, maxLines = 10)
            }
            NoteType.CHECKLIST, NoteType.ACTIVITY -> {
                h.meta.text = n.summary()
                n.items.take(12).forEachIndexed { i, item ->
                    val time = if (item.time.isNotBlank()) "${item.time}  " else ""
                    val tv = addText(h, (if (item.done) "☑  " else "☐  ") + time + item.text, 15f)
                    if (item.done) {
                        tv.paintFlags = tv.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                        tv.alpha = 0.55f
                    }
                    tv.setPadding(0, ctx.dpi(4f), 0, ctx.dpi(4f))
                    tv.setOnClickListener {
                        n.items[i].done = !n.items[i].done
                        onChanged(n)
                    }
                }
                if (n.items.size > 12) addText(h, "+${n.items.size - 12} lagi…", 13f)
                if (n.items.isEmpty()) addText(h, "(belum ada item)", 14f)
            }
            NoteType.REMINDER, NoteType.ALARM -> {
                h.meta.text = if (n.type == NoteType.REMINDER) Fmt.date(AlarmScheduler.nextTrigger(n).coerceAtLeast(0))
                else n.repeat.label
                val big = addText(h, if (n.timeMillis > 0) Fmt.time(n.timeMillis) else "--:--", 34f)
                big.typeface = t.typefaceBold()
                if (!n.enabled) big.alpha = 0.45f
                if (n.body.isNotBlank()) addText(h, n.body, 14f, maxLines = 3)
                val toggle = addText(h, if (n.enabled) "🔔 Aktif — ketuk untuk matikan" else "🔕 Nonaktif — ketuk untuk aktifkan", 13f)
                toggle.setTextColor(t.accent)
                toggle.setPadding(0, ctx.dpi(8f), 0, 0)
                toggle.setOnClickListener {
                    n.enabled = !n.enabled
                    onChanged(n)
                }
            }
        }

        v.setOnClickListener { onOpen(n) }
        h.more.setOnClickListener { onMore(n, it) }
    }

    private fun addText(h: VH, text: String, size: Float, maxLines: Int = Int.MAX_VALUE): TextView {
        val tv = TextView(ctx)
        tv.text = text
        tv.textSize = size * scale
        tv.typeface = theme.typeface()
        tv.setTextColor(theme.text)
        tv.maxLines = maxLines
        if (maxLines != Int.MAX_VALUE) tv.ellipsize = android.text.TextUtils.TruncateAt.END
        h.content.addView(tv)
        return tv
    }
}
