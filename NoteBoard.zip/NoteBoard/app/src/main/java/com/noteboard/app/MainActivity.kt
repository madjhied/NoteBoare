package com.noteboard.app

import android.Manifest
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowInsetsControllerCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: NotesAdapter
    private lateinit var list: RecyclerView
    private var filter = "ALL"
    private var notes = mutableListOf<Note>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Notifs.ensure(this)

        list = findViewById(R.id.list)
        adapter = NotesAdapter(
            this,
            onOpen = { openEditor(it.id) },
            onMore = { n, v -> showMenu(n, v) },
            onChanged = { n ->
                NoteRepo.upsert(this, n)
                AlarmScheduler.schedule(this, n)
                reload()
            }
        )
        list.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { chooseType() }
        findViewById<View>(R.id.btn_theme).setOnClickListener { pickTheme() }
        findViewById<View>(R.id.btn_settings).setOnClickListener { settings() }

        setupDrag()
        askNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        reload()
    }

    // ---------- tampilan ----------

    private fun applyTheme() {
        val t = Themes.current(this)
        findViewById<View>(R.id.main_root).background = t.background()
        window.statusBarColor = t.bgTop
        window.navigationBarColor = t.bgBottom
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !t.dark
            isAppearanceLightNavigationBars = !t.dark
        }
        val headerColor = if (t.dark) 0xFFFFFFFF.toInt() else t.text
        findViewById<TextView>(R.id.app_title).apply {
            setTextColor(headerColor)
            typeface = t.typefaceBold()
        }
        findViewById<TextView>(R.id.empty).setTextColor(if (t.dark) 0xCCFFFFFF.toInt() else t.subText)
        findViewById<FloatingActionButton>(R.id.fab).apply {
            backgroundTintList = ColorStateList.valueOf(t.accent)
            imageTintList = ColorStateList.valueOf(
                if (ColorUtils.calculateLuminance(t.accent) > 0.5) 0xFF222222.toInt() else 0xFFFFFFFF.toInt()
            )
        }
        list.layoutManager = StaggeredGridLayoutManager(Prefs.columns(this), StaggeredGridLayoutManager.VERTICAL)
        adapter.theme = t
        adapter.scale = Prefs.textScale(this)
        buildFilters(t)
    }

    private fun buildFilters(t: BoardTheme) {
        val row = findViewById<LinearLayout>(R.id.filter_row)
        row.removeAllViews()
        val options = mutableListOf("ALL" to "Semua")
        NoteType.values().forEach { options.add(it.name to "${it.icon} ${it.label}") }
        options.add("ARCHIVE" to "🗄 Arsip")
        options.forEach { (key, label) ->
            val chip = TextView(this)
            chip.text = label
            chip.textSize = 13f
            chip.typeface = t.typeface()
            chip.setPadding(dpi(14f), dpi(7f), dpi(14f), dpi(7f))
            val selected = key == filter
            val bg = GradientDrawable().apply {
                cornerRadius = dp(50f)
                setColor(if (selected) t.accent else ColorUtils.setAlphaComponent(t.cardColor(0), 200))
            }
            chip.background = bg
            val onAccent = if (ColorUtils.calculateLuminance(t.accent) > 0.5) 0xFF222222.toInt() else 0xFFFFFFFF.toInt()
            chip.setTextColor(if (selected) onAccent else t.text)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.marginEnd = dpi(8f)
            chip.layoutParams = lp
            chip.setOnClickListener {
                filter = key
                buildFilters(t)
                reload()
            }
            row.addView(chip)
        }
    }

    private fun reload() {
        notes = NoteRepo.all(this)
        val shown = when (filter) {
            "ALL" -> notes.filter { !it.archived }
            "ARCHIVE" -> notes.filter { it.archived }
            else -> notes.filter { !it.archived && it.type.name == filter }
        }.sortedByDescending { it.pinned }
        adapter.submit(shown)
        findViewById<View>(R.id.empty).visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    // ---------- geser untuk mengurutkan ----------

    private fun setupDrag() {
        val cb = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            var moved = false
            override fun isLongPressDragEnabled(): Boolean = filter == "ALL"

            override fun onMove(rv: RecyclerView, from: RecyclerView.ViewHolder, to: RecyclerView.ViewHolder): Boolean {
                adapter.move(from.bindingAdapterPosition, to.bindingAdapterPosition)
                moved = true
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(rv: RecyclerView, viewHolder: RecyclerView.ViewHolder) {
                super.clearView(rv, viewHolder)
                if (moved) {
                    moved = false
                    val ordered = adapter.items.toList()
                    val ids = ordered.map { it.id }.toSet()
                    NoteRepo.saveAll(this@MainActivity, ordered + notes.filter { it.id !in ids })
                    reload()
                }
            }
        }
        ItemTouchHelper(cb).attachToRecyclerView(list)
    }

    // ---------- aksi ----------

    private fun openEditor(id: Long) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra("id", id))
    }

    private fun chooseType() {
        val types = NoteType.values()
        AlertDialog.Builder(this)
            .setTitle("Tambah apa?")
            .setItems(types.map { "${it.icon}   ${it.label}" }.toTypedArray()) { _, w ->
                startActivity(Intent(this, EditorActivity::class.java).putExtra("type", types[w].name))
            }
            .show()
    }

    private fun showMenu(n: Note, anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, if (n.pinned) "Lepas pin" else "📌 Sematkan di atas")
        pm.menu.add(0, 2, 1, "🎨 Ganti warna")
        pm.menu.add(0, 3, 2, "📄 Duplikat")
        pm.menu.add(0, 4, 3, if (n.archived) "↩ Pulihkan dari arsip" else "🗄 Arsipkan")
        pm.menu.add(0, 5, 4, "🗑 Hapus")
        pm.setOnMenuItemClickListener { mi ->
            when (mi.itemId) {
                1 -> { n.pinned = !n.pinned; NoteRepo.upsert(this, n) }
                2 -> { n.color += 1; NoteRepo.upsert(this, n) }
                3 -> {
                    val copy = n.duplicate(NoteRepo.newId())
                    NoteRepo.upsert(this, copy)
                    AlarmScheduler.schedule(this, copy)
                }
                4 -> {
                    n.archived = !n.archived
                    NoteRepo.upsert(this, n)
                    AlarmScheduler.schedule(this, n)
                }
                5 -> deleteWithUndo(n)
            }
            reload()
            true
        }
        pm.show()
    }

    private fun deleteWithUndo(n: Note) {
        val all = NoteRepo.all(this)
        val index = all.indexOfFirst { it.id == n.id }
        AlarmScheduler.cancel(this, n.id)
        NoteRepo.delete(this, n.id)
        reload()
        Snackbar.make(list, "Catatan dihapus", Snackbar.LENGTH_LONG)
            .setAction("Urungkan") {
                val now = NoteRepo.all(this)
                now.add(index.coerceIn(0, now.size), n)
                NoteRepo.saveAll(this, now)
                AlarmScheduler.schedule(this, n)
                reload()
            }
            .show()
    }

    private fun pickTheme() {
        val names = Themes.list.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Pilih tema")
            .setSingleChoiceItems(names, Prefs.theme(this)) { d, w ->
                Prefs.setTheme(this, w)
                d.dismiss()
                applyTheme()
                reload()
                NoteWidgetProvider.updateAll(this)
            }
            .show()
    }

    private fun settings() {
        val opts = arrayOf(
            "🎨  Tema",
            "▦  Jumlah kolom",
            "🔠  Ukuran teks & kartu",
            "⏰  Izinkan alarm layar penuh",
            "💾  Cadangkan data",
            "📥  Pulihkan data",
            "🧩  Cara pasang widget"
        )
        AlertDialog.Builder(this)
            .setTitle("Pengaturan")
            .setItems(opts) { _, w ->
                when (w) {
                    0 -> pickTheme()
                    1 -> pickColumns()
                    2 -> pickTextSize()
                    3 -> fullScreenPermission()
                    4 -> backup()
                    5 -> restore()
                    6 -> widgetHelp()
                }
            }
            .show()
    }

    private fun pickColumns() {
        AlertDialog.Builder(this)
            .setTitle("Jumlah kolom")
            .setSingleChoiceItems(arrayOf("1 kolom (kartu lebar)", "2 kolom", "3 kolom (kartu kecil)"), Prefs.columns(this) - 1) { d, w ->
                Prefs.setColumns(this, w + 1)
                d.dismiss()
                applyTheme(); reload()
            }
            .show()
    }

    private fun pickTextSize() {
        val scales = floatArrayOf(0.85f, 1f, 1.15f, 1.3f)
        val labels = arrayOf("Kecil", "Sedang", "Besar", "Sangat besar")
        val cur = scales.indexOfFirst { it == Prefs.textScale(this) }.coerceAtLeast(1)
        AlertDialog.Builder(this)
            .setTitle("Ukuran teks")
            .setSingleChoiceItems(labels, cur) { d, w ->
                Prefs.setTextScale(this, scales[w])
                d.dismiss()
                applyTheme(); reload()
            }
            .show()
    }

    private fun fullScreenPermission() {
        if (Build.VERSION.SDK_INT >= 34) {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.canUseFullScreenIntent()) {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName"))
                )
                return
            }
        }
        Toast.makeText(this, "Sudah diizinkan ✔", Toast.LENGTH_SHORT).show()
    }

    private fun backup() {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Cadangan NoteBoard")
            putExtra(Intent.EXTRA_TEXT, NoteRepo.exportJson(this@MainActivity))
        }
        startActivity(Intent.createChooser(send, "Simpan cadangan ke…"))
    }

    private fun restore() {
        val input = EditText(this)
        input.hint = "Tempel teks cadangan di sini"
        input.minLines = 4
        AlertDialog.Builder(this)
            .setTitle("Pulihkan data")
            .setMessage("Data sekarang akan diganti dengan cadangan.")
            .setView(input)
            .setPositiveButton("Pulihkan") { _, _ ->
                if (NoteRepo.importJson(this, input.text.toString())) {
                    AlarmScheduler.rescheduleAll(this)
                    reload()
                    Toast.makeText(this, "Berhasil dipulihkan", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Teks cadangan tidak valid", Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun widgetHelp() {
        AlertDialog.Builder(this)
            .setTitle("Pasang widget di beranda")
            .setMessage(
                "1. Tahan bagian kosong di layar beranda.\n" +
                    "2. Pilih \"Widget\", cari NoteBoard.\n" +
                    "3. Tahan dan seret ke beranda.\n" +
                    "4. Pilih isi widget (ringkasan atau satu catatan).\n\n" +
                    "Ubah ukuran: tahan widget lalu tarik titik di tepinya.\n" +
                    "Ganti isi: tahan widget → ikon pensil/Pengaturan widget.\n" +
                    "Checklist bisa dicentang langsung dari widget."
            )
            .setPositiveButton("Oke", null)
            .show()
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
