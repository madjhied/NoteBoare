package com.noteboard.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class NoteType(val label: String, val icon: String) {
    NOTE("Catatan", "📝"),
    CHECKLIST("Checklist", "✅"),
    ACTIVITY("Daftar Kegiatan", "📅"),
    REMINDER("Pengingat", "🔔"),
    ALARM("Alarm", "⏰")
}

enum class Repeat(val label: String) {
    NONE("Sekali"),
    DAILY("Setiap hari"),
    WEEKLY("Setiap minggu")
}

data class Item(var text: String, var done: Boolean = false, var time: String = "")

data class Note(
    val id: Long,
    var type: NoteType,
    var title: String = "",
    var body: String = "",
    val items: MutableList<Item> = mutableListOf(),
    var color: Int = 0,
    var pinned: Boolean = false,
    var timeMillis: Long = 0L,
    var repeat: Repeat = Repeat.NONE,
    var enabled: Boolean = true,
    var archived: Boolean = false
) {
    fun displayTitle(): String = title.ifBlank { type.label }

    fun summary(): String = when (type) {
        NoteType.NOTE -> body.lineSequence().firstOrNull { it.isNotBlank() } ?: "(kosong)"
        NoteType.CHECKLIST, NoteType.ACTIVITY -> "${items.count { it.done }}/${items.size} selesai"
        NoteType.REMINDER, NoteType.ALARM -> Fmt.schedule(this)
    }

    fun duplicate(newId: Long): Note =
        copy(id = newId, items = items.map { it.copy() }.toMutableList(), pinned = false)

    fun toJson(): JSONObject {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("t", it.text).put("d", it.done).put("tm", it.time)) }
        return JSONObject()
            .put("id", id)
            .put("type", type.name)
            .put("title", title)
            .put("body", body)
            .put("items", arr)
            .put("color", color)
            .put("pinned", pinned)
            .put("time", timeMillis)
            .put("repeat", repeat.name)
            .put("enabled", enabled)
            .put("archived", archived)
    }

    companion object {
        fun fromJson(o: JSONObject): Note {
            val arr = o.optJSONArray("items") ?: JSONArray()
            val items = MutableList(arr.length()) { i ->
                val j = arr.getJSONObject(i)
                Item(j.optString("t"), j.optBoolean("d"), j.optString("tm"))
            }
            return Note(
                id = o.getLong("id"),
                type = runCatching { NoteType.valueOf(o.optString("type")) }.getOrDefault(NoteType.NOTE),
                title = o.optString("title"),
                body = o.optString("body"),
                items = items,
                color = o.optInt("color"),
                pinned = o.optBoolean("pinned"),
                timeMillis = o.optLong("time"),
                repeat = runCatching { Repeat.valueOf(o.optString("repeat")) }.getOrDefault(Repeat.NONE),
                enabled = o.optBoolean("enabled", true),
                archived = o.optBoolean("archived")
            )
        }
    }
}

object Fmt {
    private val loc = Locale("id", "ID")
    fun time(ms: Long): String = SimpleDateFormat("HH:mm", loc).format(Date(ms))
    fun date(ms: Long): String = SimpleDateFormat("EEE, d MMM yyyy", loc).format(Date(ms))

    fun schedule(n: Note): String {
        if (n.timeMillis <= 0) return "Belum diatur"
        val next = AlarmScheduler.nextTrigger(n)
        val t = if (next > 0) next else n.timeMillis
        val base = if (n.type == NoteType.ALARM) time(t) else "${date(t)} ${time(t)}"
        val rep = if (n.repeat != Repeat.NONE) " · ${n.repeat.label}" else ""
        val st = if (!n.enabled) " · nonaktif" else ""
        return base + rep + st
    }

    fun until(ms: Long): String {
        val mins = ((ms - System.currentTimeMillis()) / 60000L).coerceAtLeast(0)
        val h = mins / 60
        val m = mins % 60
        return when {
            h >= 24 -> "${h / 24} hari ${h % 24} jam"
            h > 0 -> "$h jam $m menit"
            else -> "$m menit"
        }
    }
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun columns(c: Context) = sp(c).getInt("columns", 2)
    fun setColumns(c: Context, v: Int) = sp(c).edit().putInt("columns", v).apply()

    fun textScale(c: Context) = sp(c).getFloat("textScale", 1f)
    fun setTextScale(c: Context, v: Float) = sp(c).edit().putFloat("textScale", v).apply()

    /** -1 = ringkasan semua catatan */
    fun widgetNote(c: Context, widgetId: Int): Long = sp(c).getLong("w_$widgetId", -1L)
    fun setWidgetNote(c: Context, widgetId: Int, noteId: Long) =
        sp(c).edit().putLong("w_$widgetId", noteId).commit()

    fun removeWidget(c: Context, widgetId: Int) = sp(c).edit().remove("w_$widgetId").apply()
}

object NoteRepo {
    private fun sp(c: Context) = c.getSharedPreferences("notes", Context.MODE_PRIVATE)

    fun all(c: Context): MutableList<Note> {
        val raw = sp(c).getString("data", null) ?: return seed(c)
        return try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { Note.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            mutableListOf()
        }
    }

    fun get(c: Context, id: Long): Note? = all(c).find { it.id == id }

    fun saveAll(c: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp(c).edit().putString("data", arr.toString()).commit()
        NoteWidgetProvider.updateAll(c)
    }

    fun upsert(c: Context, n: Note) {
        val l = all(c)
        val i = l.indexOfFirst { it.id == n.id }
        if (i >= 0) l[i] = n else l.add(0, n)
        saveAll(c, l)
    }

    fun delete(c: Context, id: Long) = saveAll(c, all(c).filter { it.id != id })

    private var lastId = 0L
    fun newId(): Long {
        var id = System.currentTimeMillis()
        if (id <= lastId) id = lastId + 1
        lastId = id
        return id
    }

    fun exportJson(c: Context): String = sp(c).getString("data", "[]") ?: "[]"

    fun importJson(c: Context, json: String): Boolean = try {
        val arr = JSONArray(json.trim())
        val list = MutableList(arr.length()) { Note.fromJson(arr.getJSONObject(it)) }
        saveAll(c, list)
        true
    } catch (e: Exception) {
        false
    }

    private fun seed(c: Context): MutableList<Note> {
        val list = mutableListOf(
            Note(
                newId(), NoteType.NOTE, "Selamat datang 👋",
                "Tekan + untuk menambah catatan.\nTahan kartu lalu geser untuk mengubah urutan.\n" +
                    "Pasang widget: tahan layar beranda → Widget → NoteBoard.",
                color = 0
            ),
            Note(
                newId(), NoteType.CHECKLIST, "Belanja",
                items = mutableListOf(Item("Beras"), Item("Telur"), Item("Sabun", true), Item("Kopi")),
                color = 1
            ),
            Note(
                newId(), NoteType.ACTIVITY, "Kegiatan hari ini",
                items = mutableListOf(
                    Item("Olahraga pagi", false, "06:00"),
                    Item("Rapat kantor", false, "09:00"),
                    Item("Jemput anak", false, "15:30")
                ),
                color = 2
            )
        )
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        sp(c).edit().putString("data", arr.toString()).commit()
        return list
    }
}
