package com.noteboard.app

import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AlarmActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_alarm)

        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        val note = NoteRepo.get(this, id)
        val t = Themes.current(this)

        findViewById<android.view.View>(R.id.alarm_root).background = t.background()
        findViewById<TextView>(R.id.alarm_time).apply {
            text = Fmt.time(System.currentTimeMillis())
            setTextColor(if (t.dark) 0xFFFFFFFF.toInt() else t.text)
            typeface = t.typefaceBold()
        }
        findViewById<TextView>(R.id.alarm_label).apply {
            text = "⏰ " + (note?.displayTitle() ?: "Alarm")
            setTextColor(if (t.dark) 0xFFFFFFFF.toInt() else t.text)
            typeface = t.typeface()
        }
        findViewById<Button>(R.id.alarm_snooze).apply {
            text = "Tunda ${AlarmScheduler.SNOOZE_MIN} menit"
            setOnClickListener { AlarmScheduler.snooze(this@AlarmActivity, id); finish() }
        }
        findViewById<Button>(R.id.alarm_dismiss).setOnClickListener {
            AlarmScheduler.dismiss(this, id)
            finish()
        }
    }
}
